import java.util.stream.*;
import java.util.*;

public class Template {
    static Stream<Integer> hailStoneNumber(int n, int m) {
        // TODO
        return null;
    }

    static long hailstoneLength(int n) {
        // TODO
        return 0L;
    }

    static Stream<ImmutableSet<Integer>> powerSetStream(Set<Integer> set) {
        // TODO
        return null;
    }

    static Stream<Integer> streamHailstoneLength(int n) {
        // TODO
        return null;
    }
    
    public static void main(String[] args) {
        Stream<Integer> s1 = hailStoneNumber(2, 2);
        Stream<Integer> s2 = hailStoneNumber(3, 9);
        s1.forEach(System.out::println);
        System.out.println("---------------");
        s2.forEach(System.out::println);
        System.out.println("---------------");
        long i1 = hailstoneLength(2);
        long i2 = hailstoneLength(3);
        System.out.println(i1);
        System.out.println("---------------");
        System.out.println(i2);
        System.out.println("---------------");
        Set<Integer> inputSet = Set.of(1, 2, 3);
        powerSetStream(inputSet).forEach(System.out::println);
    }
}
